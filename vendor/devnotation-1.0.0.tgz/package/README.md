# Devnotation

> **"Pointing beats describing."**  
> The visual feedback tool for AI coding agents (Claude Code, Cursor, Codex, Grok, and Windsurf).

Devnotation bridges the gap between visual design intent and AI code execution. Instead of awkwardly explaining UI bugs in chat (*"the blue button in the sidebar, no the other one"*), click directly on your `localhost` interface to produce structured, machine-readable context.

---

## 🚀 Live Demo & Development

The development server is running locally:
```bash
npm run dev
# ➜ Local: http://localhost:5173/
```

To create a production build (showcase site + npm library bundle):
```bash
npm run build
```

---

## ✨ Key Features (Matching & Exceeding Agentation v3.1.2)

### 1. Exact Source File & Line Number (`_debugSource`)
Devnotation inspects underlying React Fiber nodes (`fiber._debugSource` and `fiber._debugOwner`) to give the AI agent the **exact file path, line number, and column** (e.g., `Source: src/components/AddReservation.tsx:65:29`). The AI agent jumps straight to the line with zero guessing.

### 2. Full DOM Path & Semantic Sibling Context
* **Full Hierarchy:** Traverses parent nodes to give the complete chain (`body > div#root > main > table > tbody > tr:nth-of-type(3) > td`).
* **Sibling Context:** Extracts previous sibling, current element text, and next sibling (e.g. `[before: "Add Room"] [current: "Active"] [after: "Delete"]`).

### 3. Environment & Viewport Metadata
Captures the active route (`/add-reservation`), full URL (`http://localhost:3000/add-reservation`), viewport dimensions (`1280×720`), and device pixel ratio (DPR: 2) on every annotation.

### 4. Click to Annotate & Grep-Friendly Selectors
Click the prominent **+ Annotate** button on the floating toolbar or press key **A**. Devnotation automatically extracts clean semantic selectors (e.g. `button#btn-deploy.bg-blue-600` or `header > div.nav > a.active`).

### 5. Text & Area Box Selection
* **Text Selection:** Highlight text strings to flag exact copy edits and wording updates.
* **Area Selection:** Drag rectangular bounding boxes over any arbitrary layout area, multi-column grid, or empty space.

### 6. Live Animation Freezing
Click the **Pause** icon in the toolbar to freeze running CSS keyframe animations, transitions, and HTML5 video loops on that exact frame. Inspect transient states and timing bugs effortlessly.

### 7. Computed Styles Inspection
Extracts real layout metrics and design tokens—including width, height, colors, font family, padding, border-radius, and box shadow.

### 8. Four Agent-Ready Output Formats
* **Compact Mode:** Minimal bulleted punchlist (`~45 tokens/item`).
* **Standard Mode (Recommended):** High-precision component context, source file:line, directive, and styles (`~120 tokens/item`).
* **Detailed Mode:** Full bounding box coordinates (`x, y, w, h`) and complete stylesheet (`~210 tokens/item`).
* **Forensic Mode:** Deep YAML DOM dump with raw HTML snippets and attribute chains (`~340 tokens/item`).

### 9. Model Context Protocol (MCP) Ready
Start the local MCP daemon:
```bash
npx -y devnotation-mcp
```
Connect Claude Code or Cursor directly to `http://localhost:4747` so your AI agent can read, query, and autonomously resolve pending design issues without manual copy-pasting.

---

## 📦 How to Install & Use in Any React / Next.js Project (e.g. HotelManagementOS)

### 1. Local Project Installation
Since Devnotation is configured as a standalone package with dual ESM/CJS and `.d.ts` bundles, you can install it into any project on your computer:

```bash
# Option A: Install directly from the local directory
npm install d:/Development/Devnotation

# Option B: Install via pre-built tarball package
npm install d:/Development/Devnotation/devnotation-1.0.0.tgz

# Option C: Use npm link
cd d:/Development/Devnotation && npm link
cd path/to/your-project && npm link devnotation
```

### 2. Drop into Your Application

#### Next.js (App Router)
```tsx
// app/layout.tsx
import { Devnotation } from 'devnotation';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        {children}
        {process.env.NODE_ENV === 'development' && <Devnotation />}
      </body>
    </html>
  );
}
```

#### Vite + React
```tsx
// src/App.tsx
import { Devnotation } from 'devnotation';

export function App() {
  return (
    <>
      <YourMainApplication />
      {import.meta.env.DEV && <Devnotation />}
    </>
  );
}
```

---

## ⌨️ Keyboard Shortcuts
* `A` or `Ctrl+Shift+A`: Toggle Annotate Mode
* `Ctrl+Enter` / `Cmd+Enter`: Instant Save Annotation Note
* `Escape`: Cancel current selection or close active inspection popover
* `Pause Button`: Freeze / unfreeze CSS animations and transitions

---

## 📄 License
MIT License.
